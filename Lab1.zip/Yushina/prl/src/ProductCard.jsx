import { useState } from "react";
import "./ProductCard.css";

function ProductCard({ name, price, image }) {
  const [count, setCount] = useState(0);

  function handleAdd() {
    setCount(count + 1);
  }

  return (
    <div className="product-card">
      <img src={image} alt={name} className="product-image" />
      <h2 className="product-name">{name}</h2>
      <p className="product-price">{price} ₽</p>
      <button className="add-btn" onClick={handleAdd}>
        Добавить в корзину
      </button>
      {count > 0 && (
        <p className="product-count">В корзине: {count}</p>
      )}
    </div>
  );
}

export default ProductCard;
